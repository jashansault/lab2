package org.example.database_crud;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.Statement;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        TableView<User> tableView = new TableView<>();
        TextField idField = new TextField(); idField.setPromptText("ID");
        TextField nameField = new TextField(); nameField.setPromptText("Name");
        TextField emailField = new TextField(); emailField.setPromptText("Email");

        Button insertButton = new Button("Insert");
        Button updateButton = new Button("Update");
        Button deleteButton = new Button("Delete");
        Button viewButton = new Button("View Data");

        HBox inputBox = new HBox(10, idField, nameField, emailField);
        HBox buttonBox = new HBox(10, insertButton, updateButton, deleteButton, viewButton);

        VBox layout = new VBox(15, tableView, inputBox, buttonBox);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");

        primaryStage.setTitle("CRUD Application - Jashanpreet Singh - 23095290 - 2025-02-21");
        primaryStage.setScene(new Scene(layout, 800, 500));
        primaryStage.show();
        insertButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("INSERT INTO users (name, email) VALUES ('" + name + "', '" + email + "')");
                tableView.setItems(UserController.getUsers());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        updateButton.setOnAction(e -> {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            String email = emailField.getText();
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("UPDATE users SET name='" + name + "', email='" + email + "' WHERE id=" + id);
                tableView.setItems(UserController.getUsers());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        deleteButton.setOnAction(e -> {
            int id = Integer.parseInt(idField.getText());
            try (Connection conn = DatabaseConnection.getConnection();
                 Statement stmt = conn.createStatement()) {

                stmt.executeUpdate("DELETE FROM users WHERE id=" + id);
                tableView.setItems(UserController.getUsers());  // Refresh the table after deletion
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        UserController.setupTable(tableView);  // Set up columns
        tableView.setItems(UserController.getUsers()); // Load data


    }

    public static void main(String[] args) {
        launch(args);
    }
}
